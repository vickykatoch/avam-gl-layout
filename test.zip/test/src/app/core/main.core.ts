import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { CoreAppModule } from './app.module';
platformBrowserDynamic().bootstrapModule(CoreAppModule);
