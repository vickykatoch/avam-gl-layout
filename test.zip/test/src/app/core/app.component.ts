import { Component } from '@angular/core';

@Component({
  selector: 'core-app',
  templateUrl: './app.component.html',
  styleUrls : ['./app.component.css']
})
export class AppComponent {
  meaning: number;
  
  constructor() {
    this.meaning = 20;
  }
}
